import { User } from './user.model';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-address-card',
  templateUrl: './address-card.component.html',
  styleUrls: ['./address-card.component.css']
})

//OnInit forces us to use ngOnInit() method which is known by angular
//We can remove the 'implements OnInit' part and still run the application perfectly becuase,
//Angular only cares that their is ngOnInit() method in the component 
export class AddressCardComponent implements OnInit {

  //This will make root component(parent) to pass instance of the user to address card component
  //We do this in the class of the app-component
  @Input('user')
  userObj:User; //Whatever gets populated automatically will be updated in the view becuase in the html we are accessing userObj using interpolation

  isCollapsed:boolean = true;

  constructor() {
  }

  //Will be called when the component is fully intialized - after calling the constructor
  //This is a liecycle hook
  ngOnInit() {

    //Didn't put this in the costructor because,
    //when we use the selector to initialize this component from the root component, 
    //angular creates an instance of this class by calling the constructor() function
    //So angular doesn't get a chance to populate the member variable 'userAddress' before calling the constructor
    //So that input wouldn't be populated to the memeber variable and value would be set to empty.
    //when the component is fully initialized angular will definitely call ngOnInit()
    //That's why we put the 'user' object here

  //   this.user = {
  //     name: this.userObj.name,
  //     title: this.userObj.title,
  //     address: this.userObj.address,
  //     // '077334242','078232311','077231321','072321313','231212312'
  //     phone:this.userObj.phone
  // };

  }

  //This is a liecycle hook
  ngOnChanges(){
    window.alert("Data bount input property accessed!");
  }

  showContactDetails():void{
    this.isCollapsed = !this.isCollapsed;
  }

}
