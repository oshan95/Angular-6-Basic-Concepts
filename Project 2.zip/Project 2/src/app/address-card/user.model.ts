//Data transfer object
export class User{
    name:string;
    title:string;
    address:string;
    phone:string[];
}