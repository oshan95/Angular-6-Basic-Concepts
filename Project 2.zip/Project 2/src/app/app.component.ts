import { User } from './address-card/user.model';
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  nuser:User;
  isCollapsed:boolean = true;

  inputText:string= "Joey doesn't share food!";

  constructor(){
    this.nuser = new User();
    this.nuser.name = "Chandler Bing";
    this.nuser.title = "Statistical Analysis and Data Reconfiguration IT Procurements Manager ";
    this.nuser.address = " 15 Yemen Road, Yemen"
    //'077334242','078232311','077231321','072321313','231212312'
    this.nuser.phone = ['0777777777','0777777777','0777777777','0777777777','0777777777'];
  }

}
