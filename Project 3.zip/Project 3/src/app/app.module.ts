import { TestService } from './test.service';
import { ViewModule } from './view/view.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

@NgModule({
  //For Components
  declarations: [
    AppComponent,
  ],

  //For Modules
  //Directly loading modules - Not lazy ly loading modules
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ViewModule
  ],

  //Providers are used to declare services
  //Telling that test.service should need to be a part of app.module
  providers: [
    TestService
  ],

  bootstrap: [AppComponent]
})

//AppModule contains app.component
export class AppModule { }
