import { TestService } from './../../test.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-test2',
  templateUrl: './view-test2.component.html',
  styleUrls: ['./view-test2.component.css']
})
export class ViewTest2Component implements OnInit {

  constructor() {
   }

  ngOnInit() {
  }

}
