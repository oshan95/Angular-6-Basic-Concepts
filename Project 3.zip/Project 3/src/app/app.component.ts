import { TestService } from './test.service';
import { Component } from '@angular/core';
import { componentFactoryName } from '@angular/compiler';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  //Their are two ways to use a service in a class

    //1) The easiest way - Create object of the service and use it to access the methods
    //2) Dependency Injection - Have the angular framework itself to give you the instance of the service

    // 1)This is the easiest way
    // constructor(){

    //   //The problem with this approach is AppComponent need have TestService() ready to in order to do other work. 
    //   //If the TestService() is not ready we cannot do other stuff
    //   //The other problemn is TestService() might need some other serivces in order to do it's job - means nested objects are going to be involved
    //   let ts = new TestService();
    //   ts.makeAlert("Ross : Chandler entered vanilla ice look-alike contest and won!");

    // }

    //Dependency Injection - Have the angular framework itself to give you the instance of the service
    //In dependency injection we ask angular framework itself to create an instance of the service and give it to the component
    //But in order for angular to give(pass) component the instance of the service that it created,
    //we need to add an argument to the constructor with type, which type is type of service
    //It lets angular to pass an instance of the service when the angular is creating instance of this class through the constructor

    // As it turns out it their are two advantages of passing the instance of the service as argument to the constructor,
    //   1) Lets angular to pass the instance of the serivce to this component
    //   2) Let angular know what are the services need by this component

    //We don't want object to last only up to duration of the constructor. We want to hold on to this as a memeber variable.
    //To make the 'ts' a memeber variable we can use typescript shortcut of making the vriable to 'private' 
    constructor(private ts:TestService, private http:HttpClient){
      this.ts.makeAlert("Ross : Chandler entered vanilla ice look-alike contest and won!");
    }

    ngOnInit(){
      //Get method is a asynchronous method. What you get back is a asynchronous object.
      //In angular typescript world that asynchronous object is called "observable".
      //In angularjs asynchronous object is called a "Promise".
      //So we can't just assing the get method to a variable and get the object we want 
      let obs = this.http.get('https://api.github.com/users/oshan95');

      //Telling obs when it is done, give the response object(The object we want) to a particular function
      obs.subscribe((response)=> console.log(response));

    }
}
