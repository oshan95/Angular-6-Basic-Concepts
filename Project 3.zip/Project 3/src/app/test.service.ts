import { Injectable } from '@angular/core';

//Tells angular that this is a service
@Injectable({
  providedIn: 'root'
})
export class TestService {

  makeAlert(arg:string):void{
    window.alert(arg);
  }

}
