import { ErrorComponent } from './error/error.component';
import { HomeComponent } from './home/home.component';
import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SettingsComponent } from './settings/settings.component';
import { SettingsContactComponent } from './settings-contact/settings-contact.component';
import { SettingsProfileComponent } from './settings-profile/settings-profile.component';


//In this array we configure the routes
//Add the url in this array
//And map it to a component(the component that needs to load when the url in called)
//Finally pass the routes to the angular
//This is a array of objects{}, object contains the url mapping to a component 
const routes: Routes = [

  //You can have multiple urls mapped to the same component

  //Default component - Default view that need to be loaded when the page loads
  //When we don't specify the path
  //One way -- >{path:'', component:HomeComponent}, --> Not good to have mltiple urls for same component
  //Recomended way,
  // this '/' means to go to the root
  {path:'', redirectTo:'/home', pathMatch:'full'},

  //When you acess /home, angular gonna load the component and plug it into <router-outlet> tag of app.component.html
  {path:'home', component:HomeComponent},

  //When you acess /settings, angular gonna load the component and plug it into <router-outlet> tag of app.component.html
  //Configuring child routes --> /settings/child
  {
    path:'settings', 
    component:SettingsComponent, 
    children:[

      //Default component - Default view that need to be loaded when the page loads
      //When we don't specify the path
      //One way -- >{path:'', component:HomeComponent}, --> Not good to have mltiple urls for same component
      //Recomended way,
      //If we add '/' in the ridrectTo it goes to the root, 
      //since we want to stay in '/settings', we don't add '/' to the 'redirectTo' value
      {path:'', redirectTo:'profile', pathMatch:'prefix'},
      {path:'profile', component:SettingsProfileComponent},
      {path:'contact', component:SettingsContactComponent}
    ]
  },

  //When the user tries to access a path that does not exist in the web application
  //Wromg url
  // ** -> means anything
  //Will be called this when the web app recieves a request to url does not match any of above urls
  //If we don't do this browser throws an error
  {path:'**', component:ErrorComponent}
];

@NgModule({
  //Passing the routing configuration to angular
  imports: [RouterModule.forRoot(routes)],

  exports: [RouterModule]
})
export class AppRoutingModule { }
