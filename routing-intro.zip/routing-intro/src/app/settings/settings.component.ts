import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit {

  //To dynamically create routes in the view
  //Sub nav
  routes = [
    {linkName:'Profile', url:'profile'},
    {linkName:'Contact info', url:'contact'}
  ]

  constructor() { }

  ngOnInit() {
  }

}
