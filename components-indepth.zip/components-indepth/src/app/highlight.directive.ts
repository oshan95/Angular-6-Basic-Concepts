import { element } from 'protractor';
import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  //can be use this name to apply this directive any element
  selector: '[appHighlight]'
})

//This way we can apply/reuse this directive in multiple elements
//This reduce the code complexity
export class HighlightDirective {

  @Input('appHighlight')
  color = 'yellow';

  //Injecting a reference to the element that 'appHighlight' is applied to
  constructor(private element:ElementRef) { 
  
  }

  //@Hostlistner is used to call fucntion upon specific events
  @HostListener('mouseenter')
  addHighlight(){
    //nativeelement is the dom element
    this.element.nativeElement.style.backgroundColor = this.color;
  }

  //@Hostlistner is used to call fucntion upon specific events
  @HostListener('mouseleave')
  removeHighlight(){
    this.element.nativeElement.style.backgroundColor = null;
  }

}
