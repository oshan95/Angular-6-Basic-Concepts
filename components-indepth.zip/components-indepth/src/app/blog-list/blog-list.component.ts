import { BlogPostTileComponent } from './../blog-post-tile/blog-post-tile.component';
import { BlogPost } from './../blog-post';
import { Component, OnInit, ViewChild, QueryList, ViewChildren } from '@angular/core';
import { BlogDataService } from '../blog-data.service';
import { post } from 'selenium-webdriver/http';

@Component({
  selector: 'app-blog-list',
  templateUrl: './blog-list.component.html',
  styleUrls: ['./blog-list.component.scss']
})

//This component is a smart component

export class BlogListComponent implements OnInit {

  //Creating a array that is type of BlogPost class - Empty Array
  //We send this array of object to the child component
  //Two dimenstional - first dimension for page, second dimension for the blog post itself
  blogPosts:BlogPost[][];

  //To get the current page index of the array blogPosts
  currentPage:number;

  //For expand all button
  //By usinf @viewChild we are assining the blod-post-tile in the view(html) to this child blogPostTileComponent
  //Query list is used becuase their are mutiple blog-post-tile instances
  @ViewChildren('tile')
   blogPostTileComponents:QueryList<BlogPostTileComponent>;

  constructor(private blogDataService:BlogDataService) { }

  ngOnInit() {

    // this.initBlogPostsOld();
    this.currentPage = 0 ;
    this.blogPosts = this.blogDataService.getData();

  }

  updatePageNumber(newPage:number){
    this.currentPage = newPage;
  }

  // initBlogPostsOld():void{
  //   //Adding data to the blogPost array

  //   /*
  //   We can do this in the constructor also, but the best practice is to populate values to
  //   the instance of the class when the instance is fully initialized and
  //   because we need to make the constructor lightwieght as possible leaving it for dependency injection and stuff
  //   And also if we do this in the constructor our testcode will have to do whole lot of marking
  //   just to initialize a instance of the class
  //   */

  //  this.blogPosts.push(new BlogPost('Chandler Bing','Could you be any more stupider?'));
  //  this.blogPosts.push(new BlogPost('Phoebe Buffay','Smelly cat.. Smelly cat.. What are they feeding you?'));
  //  this.blogPosts.push(new BlogPost('Ross Geller','We were on a break!'));
  //  this.blogPosts.push(new BlogPost('Rachel Green','He is a transponster! transponster!'));
  //  this.blogPosts.push(new BlogPost('Joey Tribbiani','How you doin!'));
  //  this.blogPosts.push(new BlogPost('Monica Geller','Seven! Seven! Seven!'));
  //  this.blogPosts.push(new BlogPost('No One','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum'));

  // }

  initBlogPosts():void{
  }

  expandAll():void{
    this.blogPostTileComponents.
    forEach(e => e.viewFulltext());
  }

  favAll():void{
    this.blogPosts[this.currentPage] = 
    this.blogPosts[this.currentPage]
    . map(post=> ({
      title: post.title,
      description: post.description,
      isFav: true
    }));
  }


}
