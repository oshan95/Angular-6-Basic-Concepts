import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'app-paginator',
  templateUrl: './paginator.component.html',
  styleUrls: ['./paginator.component.scss']
})
export class PaginatorComponent implements OnInit {

  //To hold the number of pages inside the first array of arrau
  @Input()
  noOfPages;

  //For just to loop through using ngFor
  pages:number[];

   //This component sends out a event to the parent component when diff page number is called
  //And parent component should be able to listen to the event tha child component sends
  //This event is a output by the child component, any output from a component is an event
  //@Output is used to define an event 
  //EventEmiiter is an angular class which is a generic
  @Output()
  pageNumberClick =  new EventEmitter<number>();

  constructor() { }

  ngOnInit() {
    this.pages = new Array(this.noOfPages);
  }

  //Emitting the page number
  //Parent component should be listening to this event
  pageNumberClicked(pageNumber:number){
    //Sending the clicked page number
    this.pageNumberClick.emit(pageNumber);
  }
}
