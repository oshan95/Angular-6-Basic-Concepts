import { BlogPost } from './blog-post';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BlogDataService {

  constructor() { }

  getData():BlogPost[][]{
    return [
      //This array is for page 1
      [
        {
          title:'Chandler Bing',
          description:'Could you be any more stupider?'
        },
        {
          title:'Nora Bing',
          description:'I wrote a book about my son chandler'
        }
      ],
      //This array is for page 2
      [
        {
          title:'Phoebe Buffay',
          description:'Smelly cat.. Smelly cat.. What are they feeding you?'
        },
        {
          title:'Frank Buffay',
          description:'No, it was perfect. Telling you about my likes and dislikes. How I like to melt things and dislike things that do not melt'
        }
      ],
      //This array is for page 3
      [
        {
          title:'Ross Geller',
          description:'We were on a break!'
        },
        {
          title:'Jack Geller',
          description:'Chandler I am gonna have you arrested!, You stole my moves'
        },
        {
          title:'rose Geller',
          description:'That is a lot of information to get in 30 seconds. All right. Joey, if you want to leave, just leave. Rachel, no, you were not supposed to put beef in the trifle. It did not taste good. Phoebe, I am sorry, but I think Jacques Cousteau is dead. Monica, why you felt you had to hide the fact that you are in an important relationship is beyond me.'
        }
      ],
      //This array is for page 4
      [
        {
          title:'Rachel Green',
          description:'He is a transponster! transponster!'
        },
        {
          title:'Leonard Green',
          description:'You think you can just knock up my daughter and not marry her!'
        }
      ],
      //This array is for page 5
      [
        {
          title:'Joey Tribbiani Jr',
          description:'How you doin!!'
        },
        {
          title:'Joey Tribbiani Sr',
          description:'Hello dear!'
        }
      ]      
    ];
  }
}
