import { Pipe, PipeTransform } from '@angular/core';

/*
we could have just created this pipe function in our compnent's class itself.
But if we are using this pipe function in other components - several times that's gonna
weigh down our application, because we are implementing pipe function in several places in our app 
*/

@Pipe({
  name: 'truncate'
})
export class TruncatePipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {

    //From stack over flow
    //link - https://stackoverflow.com/questions/44669340/how-to-truncate-text-in-angular2/44669515
    const limit = args.length > 0 ? parseInt(args[0], 10) : 20;
    const trail = args.length > 1 ? args[1] : '...';
    return value.length > limit ? value.substring(0, limit) + trail : value;
  }

}
