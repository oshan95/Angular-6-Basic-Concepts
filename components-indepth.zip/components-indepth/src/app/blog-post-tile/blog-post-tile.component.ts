import { TruncatePipe } from './../truncate.pipe';
import { BlogPost } from './../blog-post';
import { Component, OnInit, Input, ViewEncapsulation, ChangeDetectionStrategy } from '@angular/core';

//This component will be used repeatedly in the blog-list component
@Component({
  selector: 'app-blog-post-tile',
  templateUrl: './blog-post-tile.component.html',
  styleUrls: ['./blog-post-tile.component.scss'],
  
  //Tells to check updates to the reference of the object variable
  //Makes the angular application more efficient 
  //Doesn't look deep into the object, just looks at top reference
  changeDetection:ChangeDetectionStrategy.OnPush

  //To remove the view encapsulation and let other component used styling classes used in this component's style
  //encapsulation: ViewEncapsulation.None
})

//This component is a dumb component
export class BlogPostTileComponent implements OnInit {

  //If the attribute name that we use to pass value to the component, 
  //is same as memeber variable name in the component,
  //We don't need to specify attribute's name in the ('') of @Input() annotaion 
  //We gets this object from the parent component 
  @Input() 
  post:BlogPost;

  //this variable is used to hold on to the deafault value of the text before truncating it
  //Used to implement functionality of viewing the full text when the truncated text is mouse clicked
  fullText:string;

  //Dependency injecting the truncate pipe
  //We have added the TruncatePipe to the providers section of the app.module.ts,
  //So the angular will be doing the dependency injection by itself
  constructor(private tp:TruncatePipe) { }

  ngOnInit() {

    /*
    Their is are two ways to use a pipe in a component's class
      1)Create instance of the pipe's class
        eg: vc:TruncatePipe = new TruncatePipe();

      2)Making the pipe class a singleton and then have it injected to the component's class - Recommended way
        How: a) Add the Pipe name(TruncatePipe) to the providers set of app.module.ts will make it a singleton
             b) Addinng the pipe as a constructor param - Injecting the pipe class
    */

    //2nd method
    this.fullText = this.post.description; //To hold on the full text before truncating it
    this.post.description = this.tp.transform(this.post.description,50);

  }

  viewFulltext(){
    this.post.description = this.fullText;
  }

  toggleFav(){
    this.post.isFav = !this.post.isFav;
  }

}