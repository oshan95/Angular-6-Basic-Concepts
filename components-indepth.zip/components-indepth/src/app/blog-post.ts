export class BlogPost {

    //For conditional styling
    //'?' makes the variable optional
    isFav?:boolean;

    //passing parameters with 'public' access modifier to the constructor makes them member variables
    //member variables mean they will be available to the wholw class, not to the constructor function itself
    //This is a feature in angular
    constructor(public title:string, public description:string){
        
    }
}
