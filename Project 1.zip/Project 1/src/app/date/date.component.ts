import { Component, OnInit } from '@angular/core';
import { getRandomString } from 'selenium-webdriver/safari';

//Registering the class as angular component
//@component annotation takes an object as the argument -- >{}
@Component({
  //Properties of the object
  selector: 'app-date',

  // dot slash(./) means the relative path to the component.ts file - Refers to the files that are in the same directory
  templateUrl: './date.component.html',

  //Array of strings that are paths to css files
  styleUrls: ['./date.component.css']
})

//Functionality provided by the component goes here
export class DateComponent implements OnInit {

  liveDate:string;
  message1:string = "Message test for interpolation";
  cvalue:number = 7;
  rnumber:number = 5;

  constructor() {
    setInterval(()=>{
      let cdate = new Date();
      this.liveDate = cdate.toDateString()+' '+cdate.toTimeString();
    },1000)
  }

  ngOnInit() {
  }

  printSomething(greeting:string):string{
    return greeting+" Oshan!";
  }

  
}
